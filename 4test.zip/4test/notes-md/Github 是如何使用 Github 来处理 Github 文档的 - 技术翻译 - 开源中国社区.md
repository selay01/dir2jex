**内容参考**

文档团队希望在编写文档的时候使用“内容参考”。通过内容参考你可以写一大段文字然后在网站任何地方复用它。（这个想法借鉴于 [<span class="underline">the
DITA standard</span>](http://dita.xml.org/arch-conref)）

旧的Rails应用并不能允许我们编写可复用的内容，但是现在我们借助于Jekyll  [<span class="underline">data
files</span>](http://jekyllrb.com/docs/datafiles/) 的力量。举个粒子，我么已经创建了一个叫做*conrefs.yml*
 的文件，并且写了一系列键-值集合的字符串就像下面这样：

?

<table>
<tbody>
<tr class="odd">
<td><p>1</p>
<p>2</p>
<p>3</p>
<p>4</p></td>
<td><p>repositories:</p>
<p>create_new:</p>
<p>1. In the upper-right corner of any page, click {{ octicon-plus Plus symbol }}, and <strong>then</strong>click **New repository**.</p>
<p>![New repository menu](/assets/images/help/repository/repo-create.png)</p></td>
</tr>
</tbody>
</table>

我们的键根据 (repositories.create\_new )特异性进行分组；其对应的值为下面的Markdown源码( "In the
upper-right corner...”)。使用使用合适的语法，我们只需要简单一步就能在不同页面引用创建一个新的仓库。

?

<table>
<tbody>
<tr class="odd">
<td><p>1</p>
<p>2</p>
<p>3</p>
<p>4</p>
<p>5</p></td>
<td><p>To start the process:</p>
<p>{{ site.data.conrefs.repositories.create_new }}</p>
<p>2. Do something <strong>else</strong>.</p>
<p>3. You're <strong>done</strong>!</p></td>
</tr>
</tbody>
</table>

随着Github的界面变化，我们也许需要修改图片或者重新定义方向的指向。这样我们只需要借助内容参考，仅仅在改变一个地方而不是很多地方。

tel.gif

id: d97cd123ee5cac070be2ae8dd597cebf
mime: image/gif
filename:
created_time: 2020-03-15T11:18:23.766Z
updated_time: 2020-03-15T11:18:23.766Z
user_created_time: 2020-03-15T11:18:23.766Z
user_updated_time: 2020-03-15T11:18:23.766Z
file_extension: gif
encryption_cipher_text:
encryption_applied: 0
encryption_blob_encrypted: 0
size: 3783
is_shared: 0
type_: 4
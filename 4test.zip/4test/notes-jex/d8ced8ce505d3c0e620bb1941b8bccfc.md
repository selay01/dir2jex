37signals倡导及实践的8个理念 _ 36氪

在软件设计界，
[<span class="underline">37signals</span>](http://37signals.com/)是非常受欢迎的一个小团队，对于
Geek 更是如此。不仅因为其自身产品的简洁、精益，更在于其对自身理念的实践。同时他们出版的书籍深受欢迎，特别是
[<span class="underline">《Getting
Real》</span>](http://book.douban.com/subject/3567853/)及
[<span class="underline">《Rework》</span>](http://book.douban.com/subject/3889178/)。下面让我们看看他们所倡导的
8 个理念，对于产品设计、企业管理甚至个人素养都具有一定参考价值。

\*\*可用性才是永恒\*

其它一切都可能消失，唯可用性永远不会。我们只建立你需要的软件，其它一切都是多余。

\*\*优质的服务就是一切\*

我们以快速和友好的客户服务著称，每天都努力确保这份荣誉。

\*\*简洁清晰是王道\*

在 37signals，口号、术语以及任何吹嘘式语言将无立足之地。我们的沟通讲求清晰与真诚。

\*\*客户就是投资者\*

我们的客户通过购买产品支持我们的日常运作，我们向他们汇报工作，而不是投资人、市场或者董事会。

\*\*基础的元素最美\*

我们从不会忽略真正重要的东西：基础元素、优质服务、易用性、可靠的价格以及对我们客户时间、金钱与信任的尊重。

\*\*定价公开\*

我们相信我们提供的价格是公道的，所有的价格面向所有人公开。

\*\*软件需要简单容易\*

我们的产品都具有直觉性，打开软件几分钟就可上手，而非花上几天甚至几周时间。我们不会给你培训而收费，因为你根本不需要。

\*\*长期合作是可憎的\*

没有人愿意将自己绑在一件不喜欢的事情上。我们的客户可以随时取消合作。



id: d8ced8ce505d3c0e620bb1941b8bccfc
parent_id: ea2a4aeaa99fa20a18242f38a58a3311
created_time: 2020-03-15T11:18:23.779Z
updated_time: 2020-03-15T11:18:23.779Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author:
source_url:
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data:
order: 0
user_created_time: 2020-03-15T11:18:23.779Z
user_updated_time: 2020-03-15T11:18:23.779Z
encryption_cipher_text:
encryption_applied: 0
markup_language: 1
is_shared: 0
type_: 1